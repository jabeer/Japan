"use strict";

angular.module("psFramework", ["psMenu", "psDashboard"]);