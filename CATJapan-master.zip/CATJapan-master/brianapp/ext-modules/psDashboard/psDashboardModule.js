"use strict";

angular.module("psDashboard", ["gridster", "ui.bootstrap"]);