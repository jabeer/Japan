"use strict";

angular.module("psMenu", ["ngAnimate"]);