    
 
  /**
 * Create a map
 */
var map = AmCharts.makeChart("chartdiv", {
  "type": "map",
  "theme": "light",
  "projection": "winkel3",
  "titles": [{
      "text": "Map of Japan",
      "size": 15
    }],

  /**
   * Data Provider
   * The images contains pie chart information
   * The handler for `positionChanged` event will take care
   * of creating external elements, position them and create
   * Pie chart instances in them
   */
  "dataProvider": {
    "map": "continentsLow",
    "zoomLevel": 7,
    "zoomLongitude": 170,
    "zoomLatitude": 35,
    "images": [{
      "title": "Hokkiado",
      "latitude": 42.923901,
      "longitude": 143.196106,
      "width": 200,
      "height": 200,
      "pie": {
        "type": "pie",
        "pullOutRadius": 0,
        "labelRadius": 0,
        "radius": "10%",
        "dataProvider": [{
          "category": "Male",
          "value": 2603345
        }, {
          "category": "Female",
          "value": 2903074
        }],
        "labelText": "",
        "valueField": "value",
        "titleField": "category"
      }
    }, {
      "title": "Tokyo",
      "latitude": 35.652832,
      "longitude": 139.839478,
      "width": 200,
      "height": 200,
      "pie": {
        "type": "pie",
        "pullOutRadius": 0,
        "labelRadius": 0,
        "radius": "10%",
        "dataProvider": [{
          "category": "Male",
          "value": 6512110
        }, {
          "category": "Female",
          "value": 6647278
        }],
        "labelText": "",
        "valueField": "value",
        "titleField": "category"
      }
    }]
  },
  
  /**
   * Add event to execute when the map is zoomed/moved
   * It also is executed when the map first loads
   */
  "listeners": [{
    "event": "positionChanged",
    "method": updateCustomMarkers
  }]
});

/**
 * Creates and positions custom markers (pie charts)
 */
function updateCustomMarkers(event) {
  // get map object
  var map = event.chart;

  // go through all of the images
  for (var x = 0; x < map.dataProvider.images.length; x++) {

    // get MapImage object
    var image = map.dataProvider.images[x];

    // Is it a Pie?
    if (image.pie === undefined) {
      continue;
    }

    // create id
    if (image.id === undefined) {
      image.id = "amcharts_pie_" + x;
    }
    // Add theme
    if ("undefined" == typeof image.pie.theme) {
      image.pie.theme = map.theme;
    }

    // check if it has corresponding HTML element
    if ("undefined" == typeof image.externalElement) {
      image.externalElement = createCustomMarker(image);
    }

    // reposition the element accoridng to coordinates
    var xy = map.coordinatesToStageXY(image.longitude, image.latitude);
    image.externalElement.style.top = xy.y + "px";
    image.externalElement.style.left = xy.x + "px";
    image.externalElement.style.marginTop = Math.round(image.height / -2) + "px";
    image.externalElement.style.marginLeft = Math.round(image.width / -2) + "px";
  }
}

/**
 * Creates a custom map marker - a div for container and a
 * pie chart in it
 */
function createCustomMarker(image) {

  // Create chart container
  var holder = document.createElement("div");
  holder.id = image.id;
  holder.title = image.title;
  holder.style.position = "absolute";
  holder.style.width = image.width + "px";
  holder.style.height = image.height + "px";

  // Append the chart container to the map container
  image.chart.chartDiv.appendChild(holder);

  // Create a pie chart
  var chart = AmCharts.makeChart(image.id, image.pie);

  return holder;
}