  var chart = AmCharts.makeChart("chart1div", {
    "theme": "light",
    "type": "serial",
    "titles": [{
      "text": "Breakdown by Year and Gender",
      "size": 15
    }],
  "dataLoader": {
    "url": "http://127.0.0.1:8080/app/japan-pop-sex.json"
  },

  "valueAxes": [{
        "stackType": "3d",
        "unit": "%",
        "position": "left",
        "title": "Japan Population By Year and Gender",
    }],
    "startDuration": 1,
    "graphs": [{
        "balloonText": "Japan Population [[category]] (Male): <b>[[value]]</b>",
        "fillAlphas": 0.9,
        "lineAlpha": 0.2,
        "title": "Male",
        "type": "column",
        "valueField": "Male"
    }, {
        "balloonText": "Japan Population [[category]] (Female): <b>[[value]]</b>",
        "fillAlphas": 0.9,
        "lineAlpha": 0.2,
        "title": "Female",
        "type": "column",
        "valueField": "Female"
    }],
    "plotAreaFillAlphas": 0.1,
    "depth3D": 60,
    "angle": 30,
    "categoryField": "Year",
    "categoryAxis": {
        "gridPosition": "start"
    },
    "export": {
      "enabled": true
     }
});
jQuery('.chart-input').off().on('input change',function() {
  var property  = jQuery(this).data('property');
  var target    = chart;
  chart.startDuration = 0;

  if ( property == 'topRadius') {
    target = chart.graphs[0];
        if ( this.value == 0 ) {
          this.value = undefined;
        }
  }

  target[property] = this.value;
  chart.validateNow();
});




