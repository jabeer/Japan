var chart = AmCharts.makeChart("chart2div", {
    "theme": "light",
    "type": "serial",
   "legend": {
        "horizontalGap": 10,
        "maxColumns": 1,
        "position": "right",
		"useGraphSettings": true,
		"markerSize": 10
    },
    "titles": [{
            "text": "Breakdown by Industry and Gender",
            "size": 15
        }],
  "dataLoader": {
    "url": "http://127.0.0.1:8080/app/japan-pop-industry-sex.json"
  },
   "valueAxes": [{
        "stackType": "regular",
        "axisAlpha": 0.5,
        "gridAlpha": 0
    }],
    "graphs": [{
        "balloonText": "<b>[[title]]</b><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>",
        "fillAlphas": 0.8,
        "labelText": "[[value]]",
        "lineAlpha": 0.3,
        "title": "Male",
        "type": "column",
		"color": "#000000",
        "valueField": "Male"
    }, {
        "balloonText": "<b>[[title]]</b><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>",
        "fillAlphas": 0.8,
        "labelText": "[[value]]",
        "lineAlpha": 0.3,
        "title": "Female",
        "type": "column",
		"color": "#000000",
        "valueField": "Female"
    }],
    "rotate": true,
    "categoryField": "2010",
    "categoryAxis": {
        "gridPosition": "start",
        "axisAlpha": 0,
        "gridAlpha": 0,
        "position": "left"
    },
    "export": {
    	"enabled": true
     }
});