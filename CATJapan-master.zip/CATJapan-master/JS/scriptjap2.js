/**
 * Application Modul;
 *
 * Description
 */
var myapp = angular.module('Application', ["ui.bootstrap"]);


myapp.controller('chartFilter', ['$scope',
    function($scope) {

        var dynamodb = new AWS.DynamoDB();

        var outputChart1 = [];

        var outputChart3 = [];

        $scope.selected1 = undefined;

        $scope.years = [
            { "Year": "1920" },
            { "Year": "1925" },
            { "Year": "1930" },
            { "Year": "1935" },
            { "Year": "1940" },
            { "Year": "1945" },
            { "Year": "1947" },
            { "Year": "1950" },
            { "Year": "1955" },
            { "Year": "1960" },
            { "Year": "1965" },
            { "Year": "1970" },
            { "Year": "1975" },
            { "Year": "1980" },
            { "Year": "1985" },
            { "Year": "1990" },
            { "Year": "1995" },
            { "Year": "2000" },
            { "Year": "2005" },
            { "Year": "2010" },
        ];

        //chart 1

        var paramsSex = {
            TableName: "japan-population-sex",
            ScanFilter: {
                "prefecture": {
                    ComparisonOperator: "CONTAINS",
                    AttributeValueList: [{ S: "Japan" }]
                }
            }
        };

        dynamodb.scan(paramsSex, function(err, data) {
            if (err) {
                alert(err, err.stack);
            } else {
                for (i = 0; i < data["Items"].length; i++) {
                    inLine = data["Items"][i];
                    outLine = {};
                    for (var key in inLine) {
                        if (key === "prefecture") {
                            continue;
                        }
                        var population = inLine[key]["S"];
                        var year = key.match(/[0-9][0-9][0-9][0-9]/)[0];
                        var sex = "Male";
                        if (/f/.test(key)) { sex = "Female"; }
                        for (var i = 0; i < $scope.years.length; i++) {
                            if ($scope.years[i]["Year"] == year) {
                                $scope.years[i][sex] = population;
                                break;
                            }
                        }
                    }
                }

                var output = $scope.years;

                $scope.updateChart = function() {
                    var newOutput = $scope.years;
                    var filteredOutput = [];
                    angular.forEach(newOutput, function(value) {
                        if ($scope.selected.value == value.Year) {
                            filteredOutput.push(value);

                        }
                    });
                    chart1.dataProvider = filteredOutput;
                    chart1.validateData();

                }

                var chart1 = AmCharts.makeChart("chart1div", {
                    "theme": "light",
                    "type": "serial",
                    "titles": [{
                        "text": "Breakdown by Year and Gender",
                        "size": 15
                    }],
                    "dataProvider": output,
                    "valueAxes": [{
                        "stackType": "3d",
                        "unit": "%",
                        "position": "left",
                        "title": "Japan Population By Year and Gender",
                    }],
                    "startDuration": 1,
                    "graphs": [{
                        "balloonText": "Japan Population [[category]] (Male): <b>[[value]]</b>",
                        "fillAlphas": 0.9,
                        "lineAlpha": 0.2,
                        "title": "Male",
                        "type": "column",
                        "valueField": "Male"
                    }, {
                        "balloonText": "Japan Population [[category]] (Female): <b>[[value]]</b>",
                        "fillAlphas": 0.9,
                        "lineAlpha": 0.2,
                        "title": "Female",
                        "type": "column",
                        "valueField": "Female"
                    }],
                    "plotAreaFillAlphas": 0.1,
                    "depth3D": 60,
                    "angle": 30,
                    "categoryField": "Year",
                    "categoryAxis": {
                        "gridPosition": "start"
                    },
                    "export": {
                        "enabled": true
                    }
                });
            }
        });
        //Chart 2
        var refreshedOutput = [];

        var outputChart2 = [];


        dynamodb.scan({ TableName: "japan-population-occupation" }, function(err, data) {
            if (err) {
                alert(err, err.stack);
            } else {
                for (i = 0; i < data["Items"].length; i++) {
                    inLine = data["Items"][i];
                    outLine = {};
                    for (var key in inLine) {
                        if (key === "occupation") {
                            outLine[key] = inLine[key]["S"];
                        } else {
                            outLine[key] = parseInt(inLine[key]["S"]);
                        }
                    }
                    outputChart2.push(outLine);

                }

                refreshedOutput = outputChart2;

                //Typeahead 

                var newData = [];

                angular.forEach(outputChart2, function(value) {
                    newData.push(value.occupation)
                });

                $scope.occupations = newData;


                $scope.onSelect = function() {

                    var refreshedOutput = [];
                    angular.forEach(outputChart2, function(value) {
                        if ($scope.selected1 == value.occupation) {
                            refreshedOutput.push(value);

                        }
                    });

                    chart2.dataProvider = refreshedOutput;
                    chart2.validateData();
                }

                $scope.$watch("selected1", function(value) {
                    if (value == "") {
                        chart2.dataProvider = outputChart2;
                        chart2.validateData();

                    }
                });

                // Breakdown by Industry chart
                var chart2 = AmCharts.makeChart("chart2div", {
                    "theme": "light",
                    "type": "serial",
                    "legend": {
                        "horizontalGap": 10,
                        "maxColumns": 1,
                        "position": "right",
                        "useGraphSettings": true,
                        "markerSize": 10
                    },
                    "titles": [{
                        "text": "Breakdown by Industry, 2005 vs 2010",
                        "size": 15
                    }],
                    "dataProvider": refreshedOutput,
                    "valueAxes": [{
                        "stackType": "regular",
                        "axisAlpha": 0.5,
                        "gridAlpha": 0
                    }],
                    "graphs": [{
                        "balloonText": "<b>[[title]]</b><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>",
                        "fillAlphas": 0.8,
                        "labelText": "[[value]]",
                        "lineAlpha": 0.3,
                        "title": "2005",
                        "type": "column",
                        "color": "#000000",
                        "valueField": "2005"
                    }, {
                        "balloonText": "<b>[[title]]</b><br><span style='font-size:14px'>[[category]]: <b>[[value]]</b></span>",
                        "fillAlphas": 0.8,
                        "labelText": "[[value]]",
                        "lineAlpha": 0.3,
                        "title": "2010",
                        "type": "column",
                        "color": "#000000",
                        "valueField": "2010"
                    }],
                    "rotate": true,
                    "categoryField": "occupation",
                    "categoryAxis": {
                        "gridPosition": "start",
                        "axisAlpha": 0,
                        "gridAlpha": 0,
                        "position": "left"
                    },
                    "export": {
                        "enabled": true
                    }
                });
            }
        });

        //chart 3


        var paramsPop = {
            TableName: "japan-population",
            ScanFilter: {
                "prefecture": {
                    ComparisonOperator: "NOT_CONTAINS",
                    AttributeValueList: [{ S: "Japan" }]
                }
            }
        };

        dynamodb.scan(paramsPop, function(err, data) {
            if (err) {
                alert(err, err.stack);
            } else {
                var output = [];
                for (i = 0; i < data["Items"].length; i++) {
                    inLine = data["Items"][i];
                    outLine = {};
                    for (var key in inLine) {
                        if (key === "prefecture") {
                            outLine[key] = inLine[key]["S"];
                        } else {
                            outLine[key] = parseInt(inLine[key]["S"]);
                        }
                    }
                    output.push(outLine);
                }

                outputChart3 = output;

                $scope.prefectures = [];

                angular.forEach(output, function(value) {
                    console.log(value.prefecture);
                    $scope.prefectures.push(value.prefecture);
                });



                $scope.onSelectPrefecture = function() {

                    var refreshedOutput = [];
                    angular.forEach(outputChart3, function(value) {

                        if ($scope.selectedprefecture == value.prefecture) {
                            refreshedOutput.push(value);

                        }
                    });

                    chart3.dataProvider = refreshedOutput;
                    chart3.validateData();
                }

                var chart3 = AmCharts.makeChart("chart3div", {
                    "type": "serial",
                    "titles": [{
                        "text": "Breakdown by Prefecture",
                        "size": 15
                    }],
                    "dataProvider": output,
                    "valueAxes": [{
                        "gridColor": "#FFFFFF",
                        "gridAlpha": 0.2,
                        "dashLength": 0
                    }],
                    "gridAboveGraphs": true,
                    "startDuration": 1,
                    "graphs": [{
                        "balloonText": "[[category]]: <b>[[value]]</b>",
                        "fillAlphas": 0.8,
                        "lineAlpha": 0.2,
                        "type": "column",
                        "valueField": "1920"
                    }],
                    "chartCursor": {
                        "categoryBalloonEnabled": false,
                        "cursorAlpha": 0,
                        "zoomable": false
                    },
                    "rotate": true,
                    "categoryField": "prefecture",
                    "categoryAxis": {
                        "gridPosition": "start",
                        "gridAlpha": 0,
                        "tickPosition": "start",
                        "tickLength": 20
                    }
                });

            }
        });

    }
]);