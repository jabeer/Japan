/*var chart = AmCharts.makeChart("chartdiv", {
  "type": "serial",
  "dataLoader": {
    "url": "https://s3-ap-southeast-2.amazonaws.com/japanpopulationdata/data/population.json"
  },
  "valueAxes": [{
    "gridColor": "#FFFFFF",
    "gridAlpha": 0.2,
    "dashLength": 0
  }],
  "gridAboveGraphs": true,
  "startDuration": 1,
  "graphs": [{
    "balloonText": "[[category]]: <b>[[value]]</b>",
    "fillAlphas": 0.8,
    "lineAlpha": 0.2,
    "type": "column",
    "valueField": "1920"
  }],
  "chartCursor": {
    "categoryBalloonEnabled": false,
    "cursorAlpha": 0,
    "zoomable": false
  },
  "categoryField": "Prefecture",
  "categoryAxis": {
    "gridPosition": "start",
    "gridAlpha": 0,
    "tickPosition": "start",
    "tickLength": 20
  }
});

function setDataSet(dataset_url) {
  AmCharts.loadFile(dataset_url, {}, function(data) {
    chart.dataProvider = AmCharts.parseJSON(data);
    chart.validateData();
  });
}
*/
AWS.config.update({
  region: "ap-southeast-1",
  endpoint: 'https://dynamodb.ap-southeast-1.amazonaws.com/',
  accessKeyId: "AKIAIM5POCAYKWF7JFHQ",
  secretAccessKey: "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"
});

var dynamodb = new AWS.DynamoDB();

var paramsPop = {
  TableName: "japan-population",
  ScanFilter: {
    "prefecture": {
      ComparisonOperator: "NOT_CONTAINS",
      AttributeValueList: [{S: "Japan"}]
    }
  }
};

dynamodb.scan(paramsPop, function(err, data) {
  if(err){
    alert(err, err.stack);
  }
  else{
    var output = [];
    for(i = 0; i < data["Items"].length; i++){
      inLine = data["Items"][i];
      outLine = {};
      for(var key in inLine){
        if (key === "prefecture"){
          outLine[key] = inLine[key]["S"];
        }else{
          outLine[key] = parseInt(inLine[key]["S"]);
        }
      }
      output.push(outLine);
    }
    //document.getElementById("json-population").innerHTML = JSON.stringify(output);
    var chart2 = AmCharts.makeChart("chartPop", {
      "type": "serial",
      "dataProvider": output,
      "valueAxes": [{
        "gridColor": "#FFFFFF",
        "gridAlpha": 0.2,
        "dashLength": 0
      }],
      "gridAboveGraphs": true,
      "startDuration": 1,
      "graphs": [{
        "balloonText": "[[category]]: <b>[[value]]</b>",
        "fillAlphas": 0.8,
        "lineAlpha": 0.2,
        "type": "column",
        "valueField": "1920"
      }],
      "chartCursor": {
        "categoryBalloonEnabled": false,
        "cursorAlpha": 0,
        "zoomable": false
      },
      "categoryField": "prefecture",
      "categoryAxis": {
        "gridPosition": "start",
        "gridAlpha": 0,
        "tickPosition": "start",
        "tickLength": 20,
        "labelRotation": 45
      }
    });
  }
});


var paramsSex = {
  TableName: "japan-population-sex",
  ScanFilter: {
    "prefecture": {
      ComparisonOperator: "CONTAINS",
      AttributeValueList: [{S: "Japan"}]
    }
  }
};
dynamodb.scan(paramsSex, function(err, data) {
  if(err){
    alert(err, err.stack);
  }
  else{
    var output = [
      {"Year": "1920"},
      {"Year": "1925"},
      {"Year": "1930"},
      {"Year": "1935"},
      {"Year": "1940"},
      {"Year": "1945"},
      {"Year": "1947"},
      {"Year": "1950"},
      {"Year": "1955"},
      {"Year": "1960"},
      {"Year": "1965"},
      {"Year": "1970"},
      {"Year": "1975"},
      {"Year": "1980"},
      {"Year": "1985"},
      {"Year": "1990"},
      {"Year": "1995"},
      {"Year": "2000"},
      {"Year": "2005"},
      {"Year": "2010"},
    ];
    for(i = 0; i < data["Items"].length; i++){
      inLine = data["Items"][i];
      outLine = {};
      for(var key in inLine){
        if (key === "prefecture"){
          continue;
        }
        var population = inLine[key]["S"];
        var year = key.match(/[0-9][0-9][0-9][0-9]/)[0];
        var sex = "Male";
        if(/f/.test(key)){sex = "Female";}
        for(var i = 0; i < output.length; i++){
          if(output[i]["Year"] == year){
            output[i][sex] = population;
            break;
          }
        }
      }
    }
    document.getElementById("json-population-sex").innerHTML = JSON.stringify(output);
/*    var chart3 = AmCharts.makeChart("chartSex", {
      "type": "serial",
      "dataProvider": output,
      "valueAxes": [{
        "gridColor": "#FFFFFF",
        "gridAlpha": 0.2,
        "dashLength": 0
      }],
      "gridAboveGraphs": true,
      "startDuration": 1,
      "graphs": [{
        "balloonText": "[[category]]: <b>[[value]]</b>",
        "fillAlphas": 0.8,
        "lineAlpha": 0.2,
        "type": "column",
        "valueField": "1920m"
      }],
      "chartCursor": {
        "categoryBalloonEnabled": false,
        "cursorAlpha": 0,
        "zoomable": false
      },
      "categoryField": "prefecture",
      "categoryAxis": {
        "gridPosition": "start",
        "gridAlpha": 0,
        "tickPosition": "start",
        "tickLength": 20,
        "labelRotation": 45
      }
    });
*/
  }
});

dynamodb.scan({TableName: "japan-population-occupation"}, function(err, data) {
  if(err){
    alert(err, err.stack);
  }
  else{
    var output = [];
    for(i = 0; i < data["Items"].length; i++){
      inLine = data["Items"][i];
      outLine = {};
      for(var key in inLine){
        if (key === "occupation"){
          outLine[key] = inLine[key]["S"];
        }else{
          outLine[key] = parseInt(inLine[key]["S"]);
        }
      }
      output.push(outLine);
    }
    //document.getElementById("json-population-occupation").innerHTML = JSON.stringify(output);
    var chart4 = AmCharts.makeChart("chartOcc", {
      "type": "serial",
      "dataProvider": output,
      "valueAxes": [{
        "gridColor": "#FFFFFF",
        "gridAlpha": 0.2,
        "dashLength": 0
      }],
      "gridAboveGraphs": true,
      "startDuration": 1,
      "graphs": [{
        "balloonText": "[[category]]: <b>[[value]]</b>",
        "fillAlphas": 0.8,
        "lineAlpha": 0.2,
        "type": "column",
        "valueField": "2010"
      }],
      "chartCursor": {
        "categoryBalloonEnabled": false,
        "cursorAlpha": 0,
        "zoomable": false
      },
      "categoryField": "occupation",
      "categoryAxis": {
        "gridPosition": "start",
        "gridAlpha": 0,
        "tickPosition": "start",
        "tickLength": 20,
        "labelRotation": 45
      }
    });
  }
});

