"use strict";

angular.module("app", ["ngRoute", "psFramework"]);